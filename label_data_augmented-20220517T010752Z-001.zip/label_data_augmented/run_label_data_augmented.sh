python3 label_data_augmented.py \
--image_path '/img/' \
--label_path '/label/' \
--save_path './result/' \

