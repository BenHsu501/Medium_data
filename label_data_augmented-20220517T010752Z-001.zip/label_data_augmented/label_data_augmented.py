import numpy as np
import cv2
from os import listdir

def get_args():
    parser = argparse.ArgumentParser()    
    parser.add_argument('--img_path', type = str, default = './img/', help = 'img path that is a folder')
    parser.add_argument('--label_path', type = str, default = './label/', help = 'label path that is a folder')    
    parser.add_argument('--save_path', type = str, default = './result/', help = 'saving path that is a folder')
    args = parser.parse_args()
    return args


#Adjust picture brightness
def change_brightness(img, value=30):
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    h, s, v = cv2.split(hsv)
    v = cv2.add(v,value)
    v[v > 255] = 255
    v[v < 0] = 0
    final_hsv = cv2.merge((h, s, v))
    img = cv2.cvtColor(final_hsv, cv2.COLOR_HSV2BGR)
    return img


args = get_args()
path_img = args.img_path
path_label = args.label_path
path1 = args.save_path

for filename in listdir(path_img):
    in_img = cv2.imread(path_img+filename)
    mask = cv2.imread(path_label+filename[:-4]+'.png')
    [w,h,c] = mask.shape
    label_mask = np.zeros((w,h,3))
    for i in range(0,w,1):
        for j in range(0,h,1):
            if mask[i,j,2] != 0:
                label_mask[i,j,:] = 255	

    #save rotate 0 degree image
    new_image = np.zeros((w,h*2,3))
    new_image[:,:h,:] = in_img
    new_image[:,h:,:] = label_mask
    filename1 = filename[:-4]+'_1.jpg'
    cv2.imwrite(path1 + filename1,new_image) 

    #save rotate 90 degree image
    img2 = cv2.rotate(in_img, cv2.cv2.ROTATE_90_CLOCKWISE)
    mask2 = cv2.rotate(label_mask, cv2.cv2.ROTATE_90_CLOCKWISE)
    new_image2 = np.zeros((h,w*2,3))
    new_image2[:,:w,:] = img2
    new_image2[:,w:,:] = mask2

    filename2 = filename[:-4]+'_2.jpg'
    cv2.imwrite(path1 + filename2,new_image2)

    #save rotate 180 degree image
    img3 = cv2.rotate(in_img, cv2.ROTATE_180)
    mask3 = cv2.rotate(label_mask, cv2.ROTATE_180)
    new_image3 = np.zeros((w,h*2,3))
    new_image3[:,:h,:] = img3
    new_image3[:,h:,:] = mask3

    filename3 = filename[:-4]+'_3.jpg'
    cv2.imwrite(path1 + filename3,new_image3)

    #save rotate 270 degree image
    img4 = cv2.rotate(in_img, cv2.ROTATE_90_COUNTERCLOCKWISE)
    mask4 = cv2.rotate(label_mask, cv2.ROTATE_90_COUNTERCLOCKWISE)
    new_image4 = np.zeros((h,w*2,3))
    new_image4[:,:w,:] = img4
    new_image4[:,w:,:] = mask4

    filename4 = filename[:-4]+'_4.jpg'
    cv2.imwrite(path1 + filename4,new_image4)


    #save mirror vertical image
    img5 = cv2.flip(in_img, 0)
    mask5 = cv2.flip(label_mask, 0)
    new_image5 = np.zeros((w,h*2,3))
    new_image5[:,:h,:] = img5
    new_image5[:,h:,:] = mask5

    filename5 = filename[:-4]+'_5.jpg'
    cv2.imwrite(path1 + filename5,new_image5)

    #save mirror Horizontal image
    img6 = cv2.flip(in_img, 1)
    mask6 = cv2.flip(label_mask, 1)
    new_image6 = np.zeros((w,h*2,3))
    new_image6[:,:h,:] = img6
    new_image6[:,h:,:] = mask6

    filename6 = filename[:-4]+'_6.jpg'
    cv2.imwrite(path1 + filename6,new_image6)

    #save brighten image
    img7 = change_brightness(in_img, value=30)
    mask7 = label_mask
    new_image7 = np.zeros((w,h*2,3))
    new_image7[:,:h,:] = img7
    new_image7[:,h:,:] = mask7

    filename7 = filename[:-4]+'_7.jpg'
    cv2.imwrite(path1 + filename7,new_image7)

    #save brighten image
    img8 = change_brightness(in_img, value=-30)
    mask8 = label_mask
    new_image8 = np.zeros((w,h*2,3))
    new_image8[:,:h,:] = img8
    new_image8[:,h:,:] = mask8

    filename8 = filename[:-4]+'_8.jpg'
    cv2.imwrite(path1 + filename8,new_image8)	

  
