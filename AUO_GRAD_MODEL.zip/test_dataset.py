import os
import cv2
import numpy as np
import torch
import random
import math
from PIL import Image, ImageDraw

from torchvision import transforms
from torch.utils.data import Dataset

import utils

class InpaintDataset(Dataset):
    def __init__(self, opt):
        self.opt = opt        
        self.imglist = utils.get_files(opt.baseroot)

    def __len__(self):
        return len(self.imglist)

    def __getitem__(self, index):
        # image
        img = cv2.imread(self.imglist[index])
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = torch.from_numpy(img.astype(np.float32) / 255.0).permute(2, 0, 1).contiguous()
        img_gray = torch.from_numpy(img_gray.astype(np.float32) / 255.0).unsqueeze(0).contiguous()
        return img, img_gray
