import os
import cv2
import numpy as np
import torch
#import imgcrop
import random
import math
from PIL import Image, ImageDraw
from torchvision import transforms
from torch.utils.data import Dataset

import utils

#Read training dataset
class InpaintDataset(Dataset):
    def __init__(self, opt):
        self.opt = opt
        self.imglist = utils.get_files(opt.baseroot)
        self.imgsize = opt.imgsize

    def __len__(self):
        return len(self.imglist)

    def __getitem__(self, index):
        W = self.imgsize
        H = self.imgsize
        img_mask = cv2.imread(self.imglist[index])
        img_mask = cv2.resize(img_mask, (2*H,W), interpolation = cv2.INTER_AREA)
        img, mask = img_mask[:, :H], img_mask[:, H:, 0]
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        img = torch.from_numpy(img.astype(np.float32) / 255.0).permute(2, 0, 1).contiguous()
        img_gray = torch.from_numpy(img_gray.astype(np.float32) / 255.0).unsqueeze(0).contiguous()
        mask = torch.from_numpy(mask.astype(np.float32) / 255.0).unsqueeze(0).contiguous()
        return img, H, W, mask, img_gray    
