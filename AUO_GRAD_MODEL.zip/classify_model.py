# Model

import torch.nn as nn
import torch.nn.functional as F
import pretrainedmodels



class backbone(nn.Module):
    def __init__(self, modelname):

        super(backbone, self).__init__()
        self.inception = pretrainedmodels.__dict__[modelname](num_classes=1000, pretrained='imagenet')#nn.Sequential(*list(inception_v3(pretrained=True).children())[:-1])
        self.maxpool = nn.AdaptiveAvgPool2d((1, 1))
    def forward(self, x):
        feat = self.inception.features(x)
        out = self.maxpool(feat)
        out = out.view((out.size(0), -1))
        return out, feat


class SupCon(nn.Module):
    def __init__(self, modelname):

        super(SupCon, self).__init__()
        self.inception = pretrainedmodels.__dict__[modelname](num_classes=1000, pretrained='imagenet')#nn.Sequential(*list(inception_v3(pretrained=True).children())[:-1])
        self.maxpool = nn.AdaptiveAvgPool2d((1, 1))
        self.head = nn.Sequential(
            nn.Linear(2048, 2048),
            nn.ReLU(inplace=True),
            nn.Linear(2048, 128)
        )
    def forward(self, x):
        feat = self.inception.features(x)
        out = self.maxpool(feat)
        out = out.view((out.size(0), -1))
        out = F.normalize(self.head(out), dim=1)
        return out
